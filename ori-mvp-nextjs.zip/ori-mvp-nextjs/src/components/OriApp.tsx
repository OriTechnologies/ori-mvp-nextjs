
import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Heart, Home, Shield, User, Gift, Sparkles, Brain, Bot, ClipboardList, Mail, FileText, Upload, Gamepad2, Coins } from "lucide-react";

type TabKey = "home" | "productivity" | "emotional" | "safety" | "redemption" | "profile";

export default function OriApp() {
  const TABS: { key: TabKey; label: string; icon: any }[] = [
    { key: "home", label: "Home", icon: Home },
    { key: "productivity", label: "Productivity", icon: ClipboardList },
    { key: "emotional", label: "Emotional", icon: Brain },
    { key: "safety", label: "Safety", icon: Shield },
    { key: "redemption", label: "Redemption", icon: Gift },
    { key: "profile", label: "Profile", icon: User },
  ];

  const [tab, setTab] = useState<TabKey>("home");
  const [askOri, setAskOri] = useState("");
  const [dailyBoost, setDailyBoost] = useState<string | null>(null);
  const [mood, setMood] = useState(50); // 0-100
  const [journal, setJournal] = useState("");
  const [wild, setWild] = useState(250); // starting WildCoin
  const [tx, setTx] = useState<Array<{ id: string; note: string; delta: number; ts: string }>>([]);
  const [signalStalkOn, setSignalStalkOn] = useState(false);
  const [productivityTool, setProductivityTool] = useState<null | string>(null);

  const addTx = (note: string, delta: number) => {
    const entry = {
      id: Math.random().toString(36).slice(2),
      note,
      delta,
      ts: new Date().toLocaleString(),
    };
    setTx((prev) => [entry, ...prev]);
  };

  const boosts = [
    "Take 3 deep breaths with a 4-4-6 count.",
    "Message someone you appreciate. 2 sentences.",
    "5-minute walk. Notice 3 colors outside.",
    "Drink a full glass of water right now.",
    "Write one worry down, then write one counter-fact.",
  ];

  const redemptionItems = [
    { id: "eco-pencil", name: "Eco Pencils (Kids)", cost: 20 },
    { id: "water-bottle", name: "Steel Water Bottle", cost: 80 },
    { id: "roblox-100", name: "Roblox Card", cost: 120 },
    { id: "minecraft-skin", name: "Minecraft Skin", cost: 90 },
    { id: "nintendo-eshop", name: "Nintendo eShop $10", cost: 150 },
    { id: "ubereats-15", name: "Uber Eats $15", cost: 180 },
    { id: "visa-25", name: "Prepaid Visa $25", cost: 300 },
    { id: "googlepay-25", name: "Google Pay $25", cost: 300 },
  ];

  const handleRedeem = (item: { id: string; name: string; cost: number }) => {
    if (wild < item.cost) return;
    setWild((w) => w - item.cost);
    addTx(`Redeemed: ${item.name}`, -item.cost);
  };

  const awardWild = (reason: string, amount = 5) => {
    setWild((w) => w + amount);
    addTx(`Reward: ${reason}`, amount);
  };

  const heartFill = useMemo(() => Math.max(0.08, mood / 100), [mood]);

  const Section = ({ title, subtitle, children, icon: Icon }: { title: string; subtitle?: string; children?: React.ReactNode; icon?: any }) => (
    <div className="bg-white/70 backdrop-blur rounded-2xl shadow p-5 md:p-7 border border-white/40">
      <div className="flex items-center gap-3 mb-3">
        {Icon && <Icon className="w-5 h-5" />}
        <h2 className="text-xl font-semibold">{title}</h2>
      </div>
      {subtitle && <p className="text-sm text-gray-600 mb-4">{subtitle}</p>}
      {children}
    </div>
  );

  const TabButton = ({ k, label, Icon }: { k: TabKey; label: string; Icon: any }) => (
    <button
      onClick={() => setTab(k)}
      className={`flex items-center gap-2 px-3 py-2 rounded-xl border transition ${
        tab === k ? "bg-black text-white border-black" : "bg-white/70 border-gray-200 hover:bg-white"
      }`}
    >
      <Icon className="w-4 h-4" />
      <span className="text-sm font-medium">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen w-full text-slate-900">
      <div className="max-w-6xl mx-auto p-4 md:p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-black text-white grid place-items-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Ori — Emotional Intelligence MVP</h1>
              <p className="text-xs text-gray-600">Interactive preview • all buttons functional</p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-2">
            {TABS.map(({ key, label, icon: I }) => (
              <TabButton key={key} k={key} label={label} Icon={I} />
            ))}
          </div>
        </div>

        {/* Mobile tabs */}
        <div className="md:hidden grid grid-cols-3 gap-2 mb-4">
          {TABS.map(({ key, label, icon: I }) => (
            <TabButton key={key} k={key} label={label} Icon={I} />
          ))}
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          {tab === "home" && (
            <motion.div key="home" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="grid md:grid-cols-3 gap-4 md:gap-6">
              {/* Ask Ori */}
              <Section title="Ask Ori" subtitle="Your emotionally intelligent copilot" icon={Search}>
                <div className="flex gap-2">
                  <input
                    className="flex-1 border rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-black/20"
                    placeholder="Ask anything…"
                    value={askOri}
                    onChange={(e) => setAskOri(e.target.value)}
                  />
                  <button
                    onClick={() => {
                      if (!askOri.trim()) return;
                      setDailyBoost(`Answer sent. Also, try this: ${boosts[Math.floor(Math.random() * boosts.length)]}`);
                      setAskOri("");
                    }}
                    className="px-4 py-2 rounded-xl bg-black text-white"
                  >Send</button>
                </div>
              </Section>

              {/* Emotional Check with animated heart */}
              <Section title="Emotional Check" subtitle="Slide to set your mood and let Ori adapt" icon={Heart}>
                <div className="flex items-center gap-4">
                  <div className="relative w-16 h-16">
                    <svg viewBox="0 0 24 24" className="w-16 h-16 absolute inset-0">
                      <path
                        d="M12 21s-6.716-4.35-9.165-8.057C1.169 10.032 2.037 7 5.053 7 6.9 7 8.24 8.36 9 9.5 9.76 8.36 11.1 7 12.947 7c3.016 0 3.884 3.032 2.218 5.943C18.716 16.65 12 21 12 21z"
                        className="fill-none stroke-black"
                      />
                    </svg>
                    <div
                      className="absolute bottom-0 left-0 w-full overflow-hidden rounded-b-[10px]"
                      style={{ height: `${heartFill * 64}px` }}
                    >
                      <div className="w-16 h-16 bg-rose-500/70" />
                    </div>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={mood}
                    onChange={(e) => setMood(parseInt(e.target.value))}
                    className="flex-1"
                  />
                  <span className="text-sm font-medium w-10 text-right">{mood}</span>
                </div>
                <div className="mt-3 text-sm text-gray-600">Ori acknowledges: {mood <= 33 ? "low" : mood <= 66 ? "steady" : "high"} energy. Suggestions update across tabs.</div>
              </Section>

              {/* Daily Boost */}
              <Section title="Daily Boost" subtitle="Tiny actions for big momentum" icon={Sparkles}>
                <div className="flex items-start gap-2">
                  <button
                    onClick={() => setDailyBoost(boosts[Math.floor(Math.random() * boosts.length)])}
                    className="px-4 py-2 rounded-xl bg-black text-white"
                  >Generate</button>
                  <p className="text-sm text-gray-700">{dailyBoost ?? "Tap Generate for a nudge."}</p>
                </div>
              </Section>

              {/* Quick tiles */}
              <div className="md:col-span-3 grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { k: "productivity", label: "Draft Email", icon: Mail },
                  { k: "productivity", label: "Write Post", icon: FileText },
                  { k: "emotional", label: "Breathing", icon: Heart },
                  { k: "safety", label: "SignalStalk", icon: Shield },
                ].map((t) => (
                  <button
                    key={t.label}
                    onClick={() => setTab(t.k as TabKey)}
                    className="bg-white rounded-2xl border p-4 flex items-center gap-3 hover:shadow"
                  >
                    <t.icon className="w-5 h-5" />
                    <span className="text-sm font-medium">{t.label}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {tab === "productivity" && (
            <motion.div key="productivity" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="grid md:grid-cols-3 gap-4 md:gap-6">
              <Section title="Work Tools" subtitle="Email, social, PDF convert, and more" icon={ClipboardList}>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "email", label: "Draft Email", icon: Mail },
                    { id: "post", label: "Write Post", icon: FileText },
                    { id: "pdf", label: "Convert PDF", icon: Upload },
                    { id: "social", label: "Social Snippets", icon: Sparkles },
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setProductivityTool(t.id)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl border ${
                        productivityTool === t.id ? "bg-black text-white border-black" : "bg-white/70 hover:bg-white"
                      }`}
                    >
                      <t.icon className="w-4 h-4" />
                      <span className="text-sm">{t.label}</span>
                    </button>
                  ))}
                </div>
                <div className="mt-4 text-sm text-gray-700">
                  {productivityTool ? (
                    <div>
                      <p className="mb-2 font-medium">{productivityTool === "email" && "Email Draft"}{productivityTool === "post" && "Social/Post Writer"}{productivityTool === "pdf" && "PDF Converter (stub)"}{productivityTool === "social" && "Snippet Generator"}</p>
                      <textarea className="w-full border rounded-xl p-3 min-h-[120px]" placeholder="Type prompt or paste text…" />
                      <div className="mt-2 flex gap-2">
                        <button className="px-3 py-2 rounded-xl bg-black text-white">Generate</button>
                        <button className="px-3 py-2 rounded-xl border">Save</button>
                      </div>
                    </div>
                  ) : (
                    <p>Select a tool to begin.</p>
                  )}
                </div>
              </Section>

              <Section title="School Zone" subtitle="Moved here from Home as requested" icon={FileText}>
                <div className="grid gap-2">
                  <button className="px-3 py-2 rounded-xl border bg-white/70 hover:bg-white">Essay Outline</button>
                  <button className="px-3 py-2 rounded-xl border bg-white/70 hover:bg-white">Summarize Chapter</button>
                  <button className="px-3 py-2 rounded-xl border bg-white/70 hover:bg-white">Study Quiz</button>
                  <button className="px-3 py-2 rounded-xl border bg-white/70 hover:bg-white">Citation Helper</button>
                </div>
              </Section>

              <Section title="Contextual Suggestions" subtitle="Adapts to mood + recent actions" icon={Sparkles}>
                <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                  <li>{mood < 40 ? "Keep tasks small—try a 10-minute focus block." : "Batch similar tasks for flow."}</li>
                  <li>{dailyBoost ? `Boost active: ${dailyBoost}` : "No boosts queued."}</li>
                  <li>Recent WildCoin: {tx[0]?.note ?? "No activity yet."}</li>
                </ul>
              </Section>
            </motion.div>
          )}

          {tab === "emotional" && (
            <motion.div key="emotional" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="grid md:grid-cols-3 gap-4 md:gap-6">
              <Section title="Breathing Coach" subtitle="4-4-6 guided (tap start)" icon={Heart}>
                <Breathing onComplete={() => awardWild("Breathing session", 5)} />
              </Section>
              <Section title="Quick Journal" subtitle="Private reflection rewards WildCoin" icon={FileText}>
                <textarea
                  className="w-full border rounded-xl p-3 min-h-[140px]"
                  placeholder="What's on your mind?"
                  value={journal}
                  onChange={(e) => setJournal(e.target.value)}
                />
                <div className="mt-2 flex gap-2">
                  <button
                    onClick={() => {
                      if (journal.trim().length >= 10) {
                        awardWild("Journaling", 10);
                        setJournal("");
                      }
                    }}
                    className="px-3 py-2 rounded-xl bg-black text-white"
                  >Save + Reward</button>
                  <button className="px-3 py-2 rounded-xl border">Analyze Emotion</button>
                </div>
              </Section>
              <Section title="Games" subtitle="Includes MoodMonster and more" icon={Gamepad2}>
                <div className="grid grid-cols-2 gap-3">
                  <GameCard name="MoodMonster" onPlay={() => awardWild("Played MoodMonster", 3)} />
                  <GameCard name="FocusDash" onPlay={() => awardWild("Played FocusDash", 3)} />
                </div>
              </Section>
            </motion.div>
          )}

          {tab === "safety" && (
            <motion.div key="safety" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="grid md:grid-cols-3 gap-4 md:gap-6">
              <Section title="SignalStalk" subtitle="Proactive safety hooks in place" icon={Shield}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-700 mb-1">Status: {signalStalkOn ? "Monitoring" : "Off"}</p>
                    <p className="text-xs text-gray-500">This preview toggles state; wire to real sensors/actions later.</p>
                  </div>
                  <button
                    onClick={() => setSignalStalkOn((s) => !s)}
                    className={`px-4 py-2 rounded-xl border ${signalStalkOn ? "bg-black text-white border-black" : "bg-white/70"}`}
                  >{signalStalkOn ? "Stop" : "Start"}</button>
                </div>
                <div className="mt-4 grid gap-2">
                  <button className="px-3 py-2 rounded-xl border">SOS Test</button>
                  <button className="px-3 py-2 rounded-xl border">Trusted Contacts</button>
                  <button className="px-3 py-2 rounded-xl border">Geo Fence</button>
                </div>
              </Section>

              <Section title="Environment" subtitle="Context from device + location (stub)" icon={Bot}>
                <ul className="text-sm text-gray-700 list-disc pl-5 space-y-1">
                  <li>Mood: {mood}</li>
                  <li>Recent Action: {dailyBoost ? "Daily Boost set" : "None"}</li>
                  <li>SignalStalk: {signalStalkOn ? "Monitoring" : "Off"}</li>
                </ul>
              </Section>

              <Section title="Recent Activity" subtitle="Audit trail" icon={FileText}>
                <div className="text-sm text-gray-700 max-h-40 overflow-auto border rounded-xl p-3 bg-white/60">
                  {tx.length === 0 && <p>No activity yet.</p>}
                  {tx.map((t) => (
                    <div key={t.id} className="flex items-center justify-between py-1">
                      <span>{t.note}</span>
                      <span className={`${t.delta > 0 ? "text-green-600" : "text-red-600"}`}>{t.delta > 0 ? "+" : ""}{t.delta}</span>
                    </div>
                  ))}
                </div>
              </Section>
            </motion.div>
          )}

          {tab === "redemption" && (
            <motion.div key="redemption" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="grid md:grid-cols-3 gap-4 md:gap-6">
              <Section title="WildCoin" subtitle="Real-time balance & Solana-style log" icon={Coins}>
                <div className="flex items-center justify-between">
                  <div className="text-3xl font-bold">{wild} <span className="text-base font-medium">WILD</span></div>
                  <button onClick={() => awardWild("Daily check-in", 2)} className="px-4 py-2 rounded-xl bg-black text-white">Check-in +2</button>
                </div>
                <div className="mt-4 text-sm text-gray-700 max-h-44 overflow-auto border rounded-xl p-3 bg-white/60">
                  {tx.length === 0 && <p>No transactions yet.</p>}
                  {tx.map((t) => (
                    <div key={t.id} className="flex items-center justify-between py-1">
                      <span>{t.ts} — {t.note}</span>
                      <span className={`${t.delta > 0 ? "text-green-600" : "text-red-600"}`}>{t.delta > 0 ? "+" : ""}{t.delta}</span>
                    </div>
                  ))}
                </div>
              </Section>

              <Section title="Redeem Items" subtitle="Click to purchase with WILD" icon={Gift}>
                <div className="grid grid-cols-2 gap-3">
                  {redemptionItems.map((it) => (
                    <button
                      key={it.id}
                      disabled={wild < it.cost}
                      onClick={() => handleRedeem(it)}
                      className={`text-left border rounded-2xl p-3 bg-white/70 hover:bg-white transition ${wild < it.cost ? "opacity-50 cursor-not-allowed" : ""}`}
                    >
                      <div className="font-medium">{it.name}</div>
                      <div className="text-sm text-gray-600">Cost: {it.cost} WILD</div>
                    </button>
                  ))}
                </div>
              </Section>

              <Section title="Notes" subtitle="Wire to Solana wallet + SKU catalog later" icon={FileText}>
                <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                  <li>Balance updates instantly on redeem.</li>
                  <li>Transaction log mimics on-chain feed (replace with RPC later).</li>
                  <li>Items represent initial marketplace (kids + adults).</li>
                </ul>
              </Section>
            </motion.div>
          )}

          {tab === "profile" && (
            <motion.div key="profile" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="grid md:grid-cols-3 gap-4 md:gap-6">
              <Section title="Account" subtitle="Accessible from navbar (as requested)" icon={User}>
                <div className="grid gap-2 text-sm">
                  <label className="grid">
                    <span className="text-gray-600 mb-1">Display Name</span>
                    <input className="border rounded-xl px-3 py-2" defaultValue="James" />
                  </label>
                  <label className="grid">
                    <span className="text-gray-600 mb-1">Email</span>
                    <input className="border rounded-xl px-3 py-2" defaultValue="james@example.com" />
                  </label>
                  <button className="mt-2 px-4 py-2 rounded-xl border">Save</button>
                </div>
              </Section>
              <Section title="Preferences" subtitle="Affects suggestions + safety sensitivity" icon={Sparkles}>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <label className="flex items-center gap-2"><input type="checkbox" defaultChecked /> Daily Boost tips</label>
                  <label className="flex items-center gap-2"><input type="checkbox" /> Low-battery alerts</label>
                  <label className="flex items-center gap-2"><input type="checkbox" defaultChecked /> Reward journaling</label>
                  <label className="flex items-center gap-2"><input type="checkbox" /> Share anonymized insights</label>
                </div>
              </Section>
              <Section title="Security" subtitle="2FA, trusted devices (stubs)" icon={Shield}>
                <div className="grid gap-2">
                  <button className="px-3 py-2 rounded-xl border">Enable 2FA</button>
                  <button className="px-3 py-2 rounded-xl border">Manage Sessions</button>
                </div>
              </Section>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom nav (always visible) */}
        <div className="sticky bottom-3 mt-8 bg-white/80 backdrop-blur rounded-2xl border shadow p-2 flex items-center justify-around">
          {TABS.map(({ key, label, icon: I }) => (
            <button key={key} onClick={() => setTab(key)} className={`flex items-center gap-2 px-3 py-2 rounded-xl ${tab === key ? "bg-black text-white" : "hover:bg-gray-100"}`}>
              <I className="w-4 h-4" />
              <span className="text-sm hidden sm:block">{label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function Breathing({ onComplete }: { onComplete?: () => void }) {
  const [phase, setPhase] = useState<"idle" | "in" | "hold" | "out">("idle");
  const [count, setCount] = useState(0);
  const [running, setRunning] = useState(false);

  React.useEffect(() => {
    let timer: any;
    if (running) {
      const cycle = async () => {
        setPhase("in"); await sleep(4000);
        setPhase("hold"); await sleep(4000);
        setPhase("out"); await sleep(6000);
        setCount((c) => c + 1);
      };
      timer = setInterval(cycle, 14000);
      cycle();
    }
    return () => clearInterval(timer);
  }, [running]);

  React.useEffect(() => {
    if (count && count % 3 === 0 && onComplete) onComplete();
  }, [count]);

  return (
    <div className="grid gap-3">
      <div className="flex items-center gap-3">
        <motion.div
          animate={{ scale: phase === "in" ? 1.2 : phase === "out" ? 0.85 : 1 }}
          transition={{ type: "spring", stiffness: 120, damping: 12 }}
          className="w-16 h-16 rounded-full bg-rose-200 grid place-items-center"
        >
          <Heart className="w-7 h-7" />
        </motion.div>
        <div>
          <div className="text-sm font-medium">Phase: {phase === "idle" ? "—" : phase}</div>
          <div className="text-xs text-gray-600">Cycles: {count}</div>
        </div>
      </div>
      <div className="flex gap-2">
        <button onClick={() => setRunning(true)} className="px-3 py-2 rounded-xl bg-black text-white">Start</button>
        <button onClick={() => { setRunning(false); setPhase("idle"); }} className="px-3 py-2 rounded-xl border">Stop</button>
      </div>
    </div>
  );
}

function GameCard({ name, onPlay }: { name: string; onPlay?: () => void }) {
  const [played, setPlayed] = useState(false);
  return (
    <div className="border rounded-2xl p-4 bg-white/70">
      <div className="font-medium mb-2">{name}</div>
      <button
        onClick={() => { setPlayed(true); onPlay && onPlay(); }}
        className={`px-3 py-2 rounded-xl ${played ? "bg-gray-200" : "bg-black text-white"}`}
      >{played ? "Played" : "Play"}</button>
    </div>
  );
}

function sleep(ms: number) { return new Promise((res) => setTimeout(res, ms)); }
