import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Ori — Emotional Intelligence MVP",
  description: "Emotionally intelligent AI wearable platform preview",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
