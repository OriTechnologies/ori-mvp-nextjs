'use client'
import OriApp from "@/components/OriApp";

export default function Page() {
  return <OriApp />;
}
